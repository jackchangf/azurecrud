﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Grocery.WebApp.Data.Enums
{
    public enum MyAppRoleTypes
    {
        Administrator,
        Staff,
        Customer
    }
}
